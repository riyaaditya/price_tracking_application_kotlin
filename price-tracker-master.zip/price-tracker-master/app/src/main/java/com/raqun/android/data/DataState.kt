package com.raqun.android.data

/**
 * Created by tyln on 31/07/2017.
 */
enum class DataState {
    FETCHING,
    SUCCESS,
    ERROR
}