package com.raqun.android.model

/**
 * Created by tyln on 14/11/2017.
 */
enum class AlarmType(val id: Int) {
    PRICE_DROP(2)
}