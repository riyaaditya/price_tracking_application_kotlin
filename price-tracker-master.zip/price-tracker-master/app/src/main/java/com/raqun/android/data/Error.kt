package com.raqun.android.data

/**
 * Created by tyln on 27/07/2017.
 */
data class Error constructor(val code: Int, val message: String)