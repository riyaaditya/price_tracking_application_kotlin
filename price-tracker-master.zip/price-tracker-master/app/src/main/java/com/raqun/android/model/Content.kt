package com.raqun.android.model

/**
 * Created by tyln on 26/08/2017.
 */
data class Content constructor(val contentId: Int,
                               val title: String,
                               val content: String)