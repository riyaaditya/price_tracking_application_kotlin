package com.raqun.android.ui.view

/**
 * Created by tyln on 07/08/2017.
 */
interface AuthView {
    fun loginButtonClicked()

    fun registerButtonClicked()
}