package com.raqun.android.ui.main.home

/**
 * Created by tyln on 02/10/2017.
 */
interface HomeView {

    fun onMoreTopClicked()

    fun onMoreRecentClicked()

    fun onMoreDiscountClicked()

    fun onMoreAppsClicked()
}