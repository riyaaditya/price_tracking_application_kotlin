package com.raqun.android.ui.main.more

/**
 * Created by tyln on 09/08/2017.
 */
interface MoreView {

    fun showAbout()

    fun showContact()

    fun rateApp()

    fun login()

    fun logout()

    fun register()
}