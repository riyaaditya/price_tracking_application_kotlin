package com.raqun.android.ui.login

/**
 * Created by tyln on 09/08/2017.
 */
interface LoginView {
    fun login()
}