package com.raqun.android.di

import javax.inject.Scope

/**
 * Created by tyln on 26/07/2017.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
internal annotation class FragmentScope