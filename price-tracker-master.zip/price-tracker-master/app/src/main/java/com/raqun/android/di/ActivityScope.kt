package com.raqun.android.di

import java.lang.annotation.RetentionPolicy
import javax.inject.Scope

/**
 * Created by tyln on 26/07/2017.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
internal annotation class ActivityScope