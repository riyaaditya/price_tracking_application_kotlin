package com.raqun.android.ui.contact

/**
 * Created by tyln on 14/08/2017.
 */
interface ContactView {
    fun sendMessage()
}