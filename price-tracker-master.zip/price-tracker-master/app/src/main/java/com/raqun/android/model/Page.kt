package com.raqun.android.model

/**
 * Created by tyln on 29/07/2017.
 */
data class Page(var start: Int = 0, val length: Int = 10)