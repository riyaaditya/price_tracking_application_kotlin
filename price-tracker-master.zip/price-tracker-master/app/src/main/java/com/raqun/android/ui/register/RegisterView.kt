package com.raqun.android.ui.register

import com.raqun.android.ui.BaseView

/**
 * Created by tyln on 07/08/2017.
 */
interface RegisterView {
    fun register()

    fun showUserAgreement()
}