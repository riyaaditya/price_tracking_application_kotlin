package com.raqun.android.ui.add

/**
 * Created by tyln on 17/10/2017.
 */
interface AddProductView {
    fun addProduct()
}