package com.raqun.android.model

/**
 * Created by tyln on 02/10/2017.
 */
enum class ProductListType {
    FAV, TOP, RECENT, DISCOUNT
}