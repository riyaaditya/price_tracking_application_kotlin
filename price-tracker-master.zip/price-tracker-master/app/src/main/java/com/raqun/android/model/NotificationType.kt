package com.raqun.android.model

/**
 * Created by tyln on 29/09/2017.
 */
enum class NotificationType {
    PRODUCT, GENERAL
}