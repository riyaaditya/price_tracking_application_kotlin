package com.raqun.android.api.request

import com.google.gson.annotations.SerializedName

/**
 * Created by tyln on 17/10/2017.
 */
data class AddProductRequest(@SerializedName("url") val url: String)