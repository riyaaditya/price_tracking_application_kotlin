package com.raqun.android.ui.product

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MediatorLiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModel
import android.util.Log
import com.raqun.android.data.DataBean
import com.raqun.android.model.Product
import com.raqun.android.model.UiDataBean
import javax.inject.Inject

/**
 * Created by tyln on 06/09/2017.
 */
class ProductViewModel @Inject constructor() : ViewModel() {

}