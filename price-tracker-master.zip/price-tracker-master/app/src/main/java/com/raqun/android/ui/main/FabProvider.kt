package com.raqun.android.ui.main

/**
 * Created by tyln on 06/10/2017.
 */
interface FabProvider {
    fun showFab()

    fun hideFab()
}