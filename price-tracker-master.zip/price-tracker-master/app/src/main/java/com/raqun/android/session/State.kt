package com.raqun.android.session

/**
 * Created by tyln on 24/10/2017.
 */
enum class State {
    LOGOUT, LOGIN, INVALID
}